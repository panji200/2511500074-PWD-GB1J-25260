<?php
  echo "halo dunia!";
?>